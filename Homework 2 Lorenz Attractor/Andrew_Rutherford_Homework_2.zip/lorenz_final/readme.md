#Lorenz Attractor

#Andrew Rutherford
#CSCI 4229

- Left & Right arrows rotate around x axis

- Up & Down arrows rotate around y axis

- A & Q increase/decrease sigma

- S & W increase/decrease rho

- D & E increase/decrease beta

- 0 will reset view angle

- 1 will reset sigma, rho, beta to default values
